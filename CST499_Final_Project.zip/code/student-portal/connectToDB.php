<?php

$serverName = "localhost";
$userName= "root";
$password = "";
$dbName="cst499";

//create Connection

$con = mysqli_connect($serverName,$userName,$password,$dbName);

?>